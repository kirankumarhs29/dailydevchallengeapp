package com.dailydevchallenge.androidapp.data.network

import io.ktor.client.*

actual fun getHttpClient(): HttpClient {
    return HttpClient(Darwin)
}