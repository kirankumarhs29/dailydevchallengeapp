package com.dailydevchallenge.androidapp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.*
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import com.dailydevchallenge.androidapp.screens.ChallengeDetailScreen
import com.dailydevchallenge.model.Challenge
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.dailydevchallenge.androidapp.screens.ChallengeListScreen
import com.dailydevchallenge.model.Difficulty


sealed class AppScreen {
    object ChallengeList : AppScreen()
    data class ChallengeDetail(val challenge: Challenge) : AppScreen()
}
@Composable
//fun App() {
//    val navController: NavHostController = rememberNavController()
//    MaterialTheme {
//        Surface(
//            modifier = Modifier.fillMaxSize(),
//            color = MaterialTheme.colorScheme.background
//        ) {
//            NavHost(navController, startDestination = "challengeList") {
//                composable("challengeList") {
//                    ChallengeListScreen(onChallengeClick = { challengeId ->
//                        navController.navigate("challengeDetail/$challengeId")
//                    })
//                }
//                composable("challengeDetail/{challengeId}") { backStackEntry ->
//                    val challengeId = backStackEntry.arguments?.getString("challengeId")?.toIntOrNull()
//                    if (challengeId != null) {
//                        ChallengeDetailScreen(
//                            challenge = Challenge(challengeId, "Sample Challenge", "This is a " +
//                                    "sample description.", Difficulty.EASY),
//                            onBack = { navController.popBackStack() },
//                            onStartChallenge = { /* Handle start challenge */ }
//                        )
//                    }
//                }
//            }
//        }
//    }
//}
fun App() {
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.ChallengeList) }

    when(val screen = currentScreen) {
        is AppScreen.ChallengeList -> ChallengeListScreen(
            onChallengeSelected = { selectedChallenge ->
                currentScreen = AppScreen.ChallengeDetail(selectedChallenge)
            }
        )

        is AppScreen.ChallengeDetail -> ChallengeDetailScreen(
            challenge = screen.challenge,
            onBack = {
                currentScreen = AppScreen.ChallengeList
            }
        )
    }
}