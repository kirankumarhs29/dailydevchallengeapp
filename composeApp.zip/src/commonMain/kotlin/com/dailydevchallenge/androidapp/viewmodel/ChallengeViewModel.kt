import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import com.dailydevchallenge.model.Challenge
import com.dailydevchallenge.model.Difficulty


class ChallengeViewModel {
    private val _currentChallenge = mutableStateOf(
        Challenge(
            id = 1,
            title = "Learn one Kotlin keyword",
            description = "Search and learn how `sealed` works in Kotlin.",
            difficulty = Difficulty.EASY,
            isCompleted = false
        )
    )
    val currentChallenge: State<Challenge> = _currentChallenge

    private val _streak = mutableStateOf(0)
    val streak: State<Int> = _streak

    fun completeChallenge() {
        if (!_currentChallenge.value.isCompleted) {
            _currentChallenge.value = _currentChallenge.value.copy(isCompleted = true)
            _streak.value += 1
        }
    }
}
