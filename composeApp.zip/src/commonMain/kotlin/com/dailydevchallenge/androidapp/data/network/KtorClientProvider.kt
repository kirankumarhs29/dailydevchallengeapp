package com.dailydevchallenge.androidapp.data.network

import io.ktor.client.*

expect fun getHttpClient(): HttpClient
