package com.dailydevchallenge.androidapp.data

import com.dailydevchallenge.androidapp.data.network.getHttpClient
import io.ktor.client.*
import io.ktor.client.request.*
import io.ktor.client.statement.*

class ApiRepository {

    private val client: HttpClient = getHttpClient()

    suspend fun getSampleData(): String {
        val response: HttpResponse = client.get("https://jsonplaceholder.typicode.com/posts/1")
        return response.bodyAsText()
    }
}
