package com.dailydevchallenge.androidapp.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.dailydevchallenge.model.Challenge

@Composable
fun ChallengeDetailScreen(
    challenge: Challenge,
    onBack: () -> Unit = {},
    onStartChallenge: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = challenge.title,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = "Difficulty: ${challenge.difficulty}",
            style = MaterialTheme.typography.labelLarge,
            color = when (challenge.difficulty.lowercase()) {
                "easy" -> Color.Green
                "medium" -> Color.Yellow
                else -> Color.Red
            }
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = challenge.description,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onStartChallenge) {
            Text("Start Challenge")
        }
    }
}
