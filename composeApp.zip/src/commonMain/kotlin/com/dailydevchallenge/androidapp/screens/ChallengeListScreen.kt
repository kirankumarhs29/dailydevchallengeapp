package com.dailydevchallenge.androidapp.screens


import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import com.dailydevchallenge.model.Challenge
import androidx.compose.material3.Text
import androidx.compose.runtime.*

import com.dailydevchallenge.androidapp.components.ChallengeCard
import com.dailydevchallenge.androidapp.data.ApiRepository
import com.dailydevchallenge.model.Difficulty
import androidx.compose.runtime.mutableStateOf


@Composable
fun ChallengeListScreen(
    onChallengeSelected: (Challenge) -> Unit = {}) {
    TestApiCall()
}

//fun ChallengeListScreen(
//    onChallengeClick: (Int) -> Unit
//) {
//    LazyColumn {
//        val challenges = listOf(
//            Challenge(1, "Jetpack Compose Intro", "Build your first UI with Compose.", Difficulty.EASY),
//            Challenge(2, "State Management", "Learn about state in Compose.", Difficulty.MEDIUM),
//            Challenge(3, "Navigation in Compose", "Implement navigation between screens.", Difficulty.HARD),
//
//        )
//        items(challenges) { challenge ->
//            ChallengeCard(challenge = challenge, onClick = {
//                onChallengeClick(challenge.id)
//            })
//        }
//    }
//    TestApiCall()
//}
@Composable
fun TestApiCall() {
    var data by remember { mutableStateOf("Loading...") }

    LaunchedEffect(Unit) {
        val repository = ApiRepository()
        try {
            data = repository.getSampleData()
        } catch (e: Exception) {
            data = "Something went wrong: ${e.message ?: "No details"}"
        }
    }

    Text(text = data)
}

