package com.dailydevchallenge.androidapp.screens

import ChallengeViewModel
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dailydevchallenge.androidapp.components.ChallengeCard

@Composable
fun DailyChallengeScreen(viewModel: ChallengeViewModel = ChallengeViewModel()) {
    val challenge by viewModel.currentChallenge
    val streak by viewModel.streak

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Your Daily Challenge", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        ChallengeCard(challenge = challenge, onClick = viewModel::completeChallenge)
        Spacer(Modifier.height(24.dp))
        Text("🔥 Streak: $streak days", fontSize = 16.sp)
    }
}
