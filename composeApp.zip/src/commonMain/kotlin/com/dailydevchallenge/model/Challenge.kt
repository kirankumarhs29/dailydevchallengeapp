package com.dailydevchallenge.model
enum class Difficulty { EASY, MEDIUM, HARD;

    fun lowercase(): Any {
        return this.name.lowercase()
    }
}

data class Challenge(
    val id: Int,
    val title: String,
    val description: String,
    val difficulty: Difficulty,
    val isCompleted: Boolean = false
)
