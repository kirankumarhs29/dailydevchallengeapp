package com.dailydevchallenge.model

import kotlinx.datetime.Instant

data class User(
    val userId: String,
    val email: String,
    val passwordHash: String, // Ideally hashed & salted
    val username: String,
    val avatarUrl: String? = null,
    val createdAt: Instant,
    val xp: Int = 0,
    val level: Int = 1,
    val dailyStreak: Int = 0,
    val lastLogin: Instant,
    val preferences: Map<String, String> = emptyMap()
)

enum class ChallengeDifficulty {
    EASY, MEDIUM, HARD
}

//data class Challenge(
//    val challengeId: String,
//    val title: String,
//    val description: String,
//    val difficulty: ChallengeDifficulty,
//    val topic: String,
//    val createdAt: Instant,
//    val updatedAt: Instant,
//    val hint: String? = null
//)

enum class ChallengeStatus {
    PENDING, COMPLETED, FAILED
}

data class UserChallengeProgress(
    val userId: String,
    val challengeId: String,
    val status: ChallengeStatus = ChallengeStatus.PENDING,
    val startedAt: Instant,
    val completedAt: Instant? = null,
    val attempts: Int = 0,
    val score: Int? = null
)
